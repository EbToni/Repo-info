<?php
// src/Controller/DefaultController.php
namespace App\Controller; // on est dans cet espace de nom
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController; 
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

use App\Service\HistoOp;
use HistoOp as GlobalHistoOp;

// On ajoute la class

class DefaultController{
    /**
     * @Route("/")
     * @Route("/bonjour/{nom<[a-z]+>?toi}/{id<\d+>?13}")
     * @param [type] $nom
     * @param [type] $id
     * @return Response
     */

public function bonjour($nom=null, $id=null) {
    if (!$nom){
    return new Response('Bonjour tout le monde !');
    } else {
    return new Response("Bonjour $nom d'id $id !");
    }
}

    // Faire multiplications de 2 entiers
/**
 * @Route("/mult/{x<\d+>?1}/{y<\d+>?1}")
 * @param int $x
 * @param int $y
 * @return Response
 */
    public function mult($x,$y){
        return new Response($x*$y);
    }
 
    // Addition de 2 entiers
/**
* @Route("/+/{x<\d+>?1}/{y<\d+>?1}")
*/
    function add($x,$y, HistoOp $histoop) : Response { 
        $r=strval(intval($x)+intval($y));
        $histoop->addOp($x.'+'.$y.'='.$r); 
        return new Response($r);
    }

    

    // Historiques des additions ci-dessus
/**
* @Route("/histo/")
*/

function histo(HistoOp $histoop) : Response {
$r="";
    foreach($histoop->getOps() as $op){
    $r.= $op."<br>";
    }
return new Response($r);
}



// Calcul de n!
/**
 * @Route("/factorielle/{n<\d+>?1}")
 */

 function factorielle(int $n) : Response{
    $fact = 1;
    for($u=1; $u<=$n; $u++){
    $fact = $fact * $u;
    }
   return new Response($fact);
 }


 // Calcul combinaison (n,p)

/**
 * @Route("/comb/{n<\d+>?1}/{p<\d+>?1}")
 */

function comb( int $n,int $p) : Response{
$factn = 1;
$factp=1;
$diff = $n - $p;
for($u=1; $u<=$n; $u++){
    $factn = $factn * $u;
    if($u == $p){
        $factp=$factn;
    }
    if($u == $diff){
        $factdiff =$factn;
    }
    }
return new Response($factn/($factp*$factdiff));

}




}