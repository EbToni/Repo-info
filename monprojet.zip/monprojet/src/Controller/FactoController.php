<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;


use Symfony\Component\HttpFoundation\Request;

class FactoController extends AbstractController
{

  

    /**
     * @Route("/facto", name="facto")
     */

     // Enlever response 
    public function index()
    {  
        $request =Request::createFromGlobals() ;

        $x= $request->query->get('k');
        $fa= factorielle($x);

         $x2= $request->query->get('k2'); 
         $x3= $request->query->get('k3');
         $cb=comb($x2,$x3) ; 
        return $this->render('facto/index.html.twig', [
            'controller_name' => 'FactoController','saisie'=> $fa, 'combi' => $cb, 'n' => $x,
            'n2' => $x2, 'n3' => $x3
        ]);
    }

    // request query get récupérer valeur d'un champs de saisie


   
}

// Enlever response

// Eviter de mettre int dans les paramètres
function factorielle($n){
    $fact = 1;
    for($u=1; $u<=$n; $u++){
    $fact = $fact * $u;
    }
   return ($fact);
 }



 function comb($n, $p) {
       return (factorielle($n)/(factorielle($p)*factorielle($n-$p)) );
    }