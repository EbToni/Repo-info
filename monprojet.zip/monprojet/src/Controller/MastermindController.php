<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

use Symfony\Component\HttpFoundation\Request;

use App\Service\Mastermind;
use App\Service\HistoOp;

class MastermindController extends AbstractController
{
    /**
     * @Route("/mastermind", name="mastermind")
     */
    public function index(): Response
    {
        $request =Request::createFromGlobals() ;
        
        return $this->render('mastermind/index.html.twig', [
            'controller_name' => 'MastermindController',
        ]);
    }
}


