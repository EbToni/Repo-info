<?php

namespace App\Controller\Admin;

use App\Entity\Tournoi;
use App\Entity\Evenement;
use EasyCorp\Bundle\EasyAdminBundle\Field\Field;
use EasyCorp\Bundle\EasyAdminBundle\Field\IdField;
use EasyCorp\Bundle\EasyAdminBundle\Config\MenuItem;
use EasyCorp\Bundle\EasyAdminBundle\Field\TextField;
use EasyCorp\Bundle\EasyAdminBundle\Field\TextEditorField;
use EasyCorp\Bundle\EasyAdminBundle\Field\AssociationField;
use EasyCorp\Bundle\EasyAdminBundle\Controller\AbstractCrudController;
use EasyCorp\Bundle\EasyAdminBundle\Field\UrlField;

class TournoiCrudController extends AbstractCrudController
{
    public static function getEntityFqcn(): string
    {
        return Tournoi::class;
    }

    // Faire un Evenement Crud ? 
    
    public function configureFields(string $pageName): iterable
    {
       
        //    yield AssociationField::new('ev'),
         // yield  Field::new('ev'),
        //  yield Field::new('evenement.nom'),         
        // yield TextField::new('ev.nom','ev'),
        // affiche ev + nom des challenge mais empeche ajout tnoi
     
        //   yield  Field::new('ev.nom','ev'),
       
        yield AssociationField::new('ev');

        //    yield  IdField::new('id'),// id -> ev
        
         yield  TextField::new('nom');
         yield TextEditorField::new('description');
      

    }
    
}
