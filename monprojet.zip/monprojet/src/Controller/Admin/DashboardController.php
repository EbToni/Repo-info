<?php

namespace App\Controller\Admin;

use App\Entity\Equipe;
use App\Entity\EquipeBasket;
use App\Entity\EquipeTennis;
use App\Entity\Tournoi;
use App\Entity\Evenement;
use App\Entity\Recapitulatif;
use App\Entity\Tarifs;
use EasyCorp\Bundle\EasyAdminBundle\Config\Dashboard;
use EasyCorp\Bundle\EasyAdminBundle\Config\MenuItem;
use EasyCorp\Bundle\EasyAdminBundle\Controller\AbstractDashboardController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;



class DashboardController extends AbstractDashboardController
{
    /**
     * @Route("/admin", name="admin")
     */
    public function index(): Response
    {
        return parent::index();
    }

    public function configureDashboard(): Dashboard
    {
        return Dashboard::new()
            ->setTitle('Monprojet');
    }

    public function configureMenuItems(): iterable
    {
      // yield MenuItem::linktoDashboard('Dashboard', 'fa fa-home'),
         yield MenuItem::linkToCrud('Tournois','fas fa-list',Tournoi::class);
         yield MenuItem::linkToCrud('Evenements','fas fa-list',Evenement::class);

        yield MenuItem::linkToCrud('Equipe football','fas fa-list',Equipe::class);
        yield MenuItem::linkToCrud('Equipe Basket','fas fa-list',EquipeBasket::class);
        yield MenuItem::linkToCrud('Joueur Tennis','fas fa-list',EquipeTennis::class);
        
        yield MenuItem::linkToCrud('Recapitulatif','fas fa-list',Recapitulatif::class);
        yield MenuItem::linkToCrud('Tarifs','fas fa-list',Tarifs::class);
     // voir pb affichage evnmt


    }
}
