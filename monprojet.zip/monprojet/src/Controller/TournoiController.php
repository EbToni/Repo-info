<?php

namespace App\Controller;


    // On utilise l'entité Evenement et Tournoi
use App\Entity\Tournoi;

use SessionIdInterface;

use App\Entity\Evenement;
use App\Form\AjoutTournoiType;
use App\Form\TournoiType;
use App\Form\EvenementType;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

use Symfony\Component\Form\FormTypeInterface;

// Pour saiseTnoi
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

use Symfony\Component\OptionsResolver\OptionsResolver;

use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;

class TournoiController extends AbstractController 
{

/*  --- Description : TournoiController ---

    1 evnt => * tournois

    1) index() <-> afficher exemple variable twig

    2) newevt <->   add evnt via le nom + crée id ($evtid) via auto increment  
        params : $nom
    
    3) newTnoi <-> evnt exist ($evtid défini)  => crée tnoi
                   evnt exist pas ($evtid  non défini) => "evt non créer"
        params : $evtid, $nom (tnoi), $desc (tnoi)

    4) saisieTnoi <-> formulaire saisir tnoi via ($evtid)
        params : $evtid

    5) (1) saisirTnoi <-> saisir un evt + un tnoi avec formulaire (de type Tnoi)
        params : ()
        <!> 2 fichers dans Form :  TournoiType + EvenementType 

        + 
        configureOptions <-> précise que le form est ( type CLASS Tournoi)

        params : $resolver
    
    6) ajTnoi <-> ajoute un tnoi en selectionner les différents evenement ajoutés
        params : $request

    7) tournois() <-> affiche liste des tournois et evenements
        params : ()
    

*/

    
    /**
     * @Route("/tournoi", name="tournoi")
     */
    public function index(): Response
    {
        $x=25;

       // --- Injection paramètres sur twig ---

       /* return $this->render('£',[ 'y1' => 'x1' ,... , 'yn' => 'xn' ])  */
        // £ <-> emplacement twig

        // 'xi' <-> variable php
        
        // 'yi' <-> (~ xi) variable twig

       return $this->render('tournoi/index.html.twig', [
            'controller_name' => 'TournoiController',
            'mavariable' => $x, 
            'liste' => ['Anthony', 'Eberlin'],
          'product' =>  ['nom' => 'marteau', 'stock' => "5"]
        ]);
    }

                        // (3) paramètres
                        // nom de l'evmt + date de l'evmt + fin de la date de l'evmt
/**
* @Route("/tournoi/newEvt/{nom<[0-9a-zA-Z ]+>}", name="newevt")
*/

public function newevt($nom): Response {
   /* µ <-> $ev */
    $ev=new Evenement(); // constructeur par défaut tjrs
   
    /* µ -> setThing()  */
    $ev->setNom($nom);
   
    /* this -> getDoctrine() -> getManager() */
    /* $entityManager -> persist(µ) */
    
    /* µ <-> correspond à un objet  */
    $entityManager = $this->getDoctrine()->getManager();
    $entityManager->persist($ev); // en tampon
   
    $entityManager->flush(); 
   
    return new Response("Événement '$nom' créé avec l'id :".$ev->getId().' !');
}




// Créer un nouveau tournoi

/**
* @Route("/tournoi/newTnoi/{evtid<[0-9]+>}/{nom<[0-9a-zA-Z, ]+>}/{desc?}", name="newTnoi")
*/


public function newTnoi($evtid, $nom, $desc) : Response{

    /*  -- Saisir des champs entité via set --
      
        $ent = new Entity()
     $ent[var1,..varn]<->  $tnoi[$nom,$desc,!id] où !id n'a pas de méthode

     $ent -> setVariable($var1) ... $ent -> setVariable($varn)
     
        */
    
    $tnoi = new Tournoi();
    $tnoi ->setNom($nom);
    $tnoi->setDescription($desc);
 
    /* 2) Y <=> $Y= $this -> getDoctrine() -> getManager()
        
            $Tab1 = $Y -> find("µ", (Type id_µ) id_µ)
    où µ <-> emplacement entité

    id_µ <-> id qui identifie l'entité µ
    */
    
    $em = $this ->getDoctrine() ->getManager();
    $evt = $em ->find("App\Entity\Evenement",(int)$evtid); // caster $evtid
    if ($evt === null){
        return new Response("L'événement $evtid n'existe pas ! Le tournoi n'a pas été créé");
    } 
    else{
        /* Y -> persist($ent) */
       /* $ent <-> correspond à $tnoi  */
        $tnoi ->setEv($evt);
        $em ->persist($tnoi);
        $em ->flush();
        return new Response("Le tournoi {$tnoi->getNom()}
         a été enregistré dans l'évènement dans l'évènement {$evt->getNom()}") ;
    }
}


 /**
* @Route("/tournoi/saisieTnoi/{evtid<[0-9]+>}", name="saisieTnoi")
*/

public function saisieTnoi($evtid): Response {
   
   /*     5 étapes         */ 
  
   // 1) Tournoi (tnoi) avec champs vide 
    $tnoi=new Tournoi();
    $tnoi->setNom("");
    $tnoi->setDescription(""); 

    // 2) crée formulaire ($tnoi)
    $form = $this->createFormBuilder($tnoi)
   
    // 3) champs form via (add)
    ->add('nom', TextType::class)
    ->add('description', TextType::class)
    ->add('sauver', SubmitType::class, ['label' => 'Créer le tournoi !'])
   
    // 4) envoyer formulaire
    ->getForm(); 

    // 5) envoie form sur twig
    return $this->render('tournoi/saisieTnoi.html.twig', ['form' => $form->createView()]);
}
        

/**
* @Route("/tournoi/saisirTnoi", name="saisirTnoi")
* AVEC type de formulaire
*/

public function saisirTnoi(Request $request) : Response {

// 1) Tournoi (tnoi)
$tnoi = new Tournoi();

// 2) crée formulaire ($tnoi) complet 
// TournoiType : form vient de TournoiType
$form = $this ->createForm(TournoiType::class, $tnoi);
$form -> handleRequest($request);

// 4) on vérifie que le formulaire est bien envoyé et bien valide
//      avant de transférer les données en BD
if($form ->isSubmitted() && $form ->isValid()){
    $entityManager =$this -> getDoctrine() -> getManager();
    $entityManager->persist($tnoi);
    $entityManager->flush();
    return $this->redirectToRoute('tournois');
    }

// 3) envoie form sur twig
return $this->render('tournoi/saisieTnoi.html.twig',  ['form' => $form->createView()]);

}

// voir autre exemple configureOptions (TournoiType)
public function configureOptions( OptionsResolver $resolver ) : void
{
$resolver -> setDefaults([
    'data_class' => Tournoi::class,
]);
}


/**
* @Route("/tournoi/ajTnoi", name="ajTnoi")
* AVEC type de formulaire
*/

public function ajTnoi(Request $request) :Response{
    
    $tnoi = new Tournoi();
    // Formulaire 
    $form = $this -> createForm(AjoutTournoiType::class,$tnoi);
    $form -> handleRequest($request);

    if( $form -> isSubmitted() && $form -> isValid() ){
        $entityManager = $this -> getDoctrine() -> getManager();
        $entityManager -> persist($tnoi);
        $entityManager -> flush();
        return $this-> redirectToRoute('tournois');
    }

    return $this->render('tournoi/saisieTnoi.html.twig',  ['form' => $form->createView()]);

}

/**
* @Route("/tournoi/tournois",name="tournois")
* liste des évts et des tournois
*/
 // Modifier le fichier tournois.html.twig

public function tournois(): Response {

    /* this -> getDoctrine() -> getManager() -> getRepository("µ") -> findAll() */
    /* µ <=> emplacement entité */

    // récupère  evenements
   $evts = $this->getDoctrine()->getManager()->getRepository("App\Entity\Evenement")->findAll();
   
    // récupère tournois
   $tournois = $this->getDoctrine()->getManager()->getRepository("App\Entity\Tournoi")->findAll();
   

   
 //récupère equipe football
   $equipe = $this->getDoctrine()->getManager()->getRepository("App\Entity\Equipe")->findAll();
   

   //récupère equipe_tennis
   $tennis = $this->getDoctrine()->getManager()->getRepository("App\Entity\EquipeTennis")->findAll();
 

    //récupère equipe_basket
    $basket = $this->getDoctrine()->getManager()->getRepository("App\Entity\EquipeBasket")->findAll();


    // Twig 'evts' => $evts et 'tournois' => $tournois 
    return $this->render('tournoi/tournois.html.twig', ['evts' => $evts, 'tournois' => $tournois, 'equipe'=>$equipe, 'tennis'=> $tennis, 'basket' => $basket ]);
}

}