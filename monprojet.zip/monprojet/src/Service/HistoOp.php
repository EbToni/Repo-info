<?php
namespace App\Service;
use Symfony\Component\HttpFoundation\Session\SessionInterface;

class HistoOp {

    private $session;
    
    public function __construct( SessionInterface $session ){
            $this->session = $session;
    }


public function addOp(string $s){
         $h=$this->session->get('histoop',[]);
         $h[]=$s; // push
         $this->session->set('histoop', $h);
                                }

public function getOps(){
            return $this->session->get('histoop');
}

}