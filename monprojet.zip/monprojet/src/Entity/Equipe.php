<?php

namespace App\Entity;

use App\Repository\EquipeRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=EquipeRepository::class)
 */
class Equipe
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=200, nullable=true)
     */
    private $nomEquipe;

    /**
     * @ORM\Column(type="string", length=200, nullable=true)
     */
    private $poule;

    /**
     * @ORM\Column(type="string", length=200, nullable=true)
     */
    private $tour;

    /**
     * @ORM\ManyToMany(targetEntity=Tournoi::class, inversedBy="equipes")
     */
    private $inscription;

    public function __construct()
    {
        $this->inscription = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    function __toString()
    {
        return $this -> inscription;
    }

    public function getNomEquipe(): ?string
    {
        return $this->nomEquipe;
    }

    public function setNomEquipe(?string $nomEquipe): self
    {
        $this->nomEquipe = $nomEquipe;

        return $this;
    }

    public function getPoule(): ?string
    {
        return $this->poule;
    }

    public function setPoule(?string $poule): self
    {
        $this->poule = $poule;

        return $this;
    }

    public function getTour(): ?string
    {
        return $this->tour;
    }

    public function setTour(?string $tour): self
    {
        $this->tour = $tour;

        return $this;
    }

    /**
     * @return Collection|Tournoi[]
     */
    public function getInscription(): Collection
    {
        return $this->inscription;
    }

    public function addInscription(Tournoi $inscription): self
    {
        if (!$this->inscription->contains($inscription)) {
            $this->inscription[] = $inscription;
        }

        return $this;
    }

    public function removeInscription(Tournoi $inscription): self
    {
        $this->inscription->removeElement($inscription);

        return $this;
    }
}
