<?php

namespace App\Entity;

use App\Repository\TournoiRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity(repositoryClass=TournoiRepository::class)
 */
class Tournoi
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity=Evenement::class, inversedBy="Sport", cascade={"persist"})
     * @Assert\Type(type="App\Entity\Evenement")
     * @Assert\Valid
     */
    private $ev;

    /**
     * @ORM\Column(type="string", length=20)
     * @Assert\NotBlank
     */
    private $nom;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $description;

    /**
     * @ORM\ManyToMany(targetEntity=Equipe::class, mappedBy="inscription")
     */
    private $equipes;

    /**
     * @ORM\ManyToMany(targetEntity=EquipeTennis::class, mappedBy="qualification")
     */
    private $equipeTennis;

    /**
     * @ORM\ManyToMany(targetEntity=EquipeBasket::class, mappedBy="relation")
     */
    private $equipeBaskets;

    /**
     * @ORM\ManyToMany(targetEntity=Recapitulatif::class, mappedBy="Final")
     */
    private $recapitulatifs;

    /**
     * @ORM\ManyToMany(targetEntity=Tarifs::class, mappedBy="relation")
     */
    private $tarifs;

    public function __construct()
    {
        $this->equipes = new ArrayCollection();
        $this->equipeTennis = new ArrayCollection();
        $this->equipeBaskets = new ArrayCollection();
        $this->recapitulatifs = new ArrayCollection();
        $this->tarifs = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEv(): ?Evenement
    {
        return $this->ev;
    }

    public function setEv(?Evenement $ev): self
    {
        $this->ev = $ev;

        return $this;
    }
    
    
    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): self
    {
        $this->description = $description;

        return $this;
    }

    /**
     * @return Collection|Equipe[]
     */
    public function getEquipes(): Collection
    {
        return $this->equipes;
    }

    public function addEquipe(Equipe $equipe): self
    {
        if (!$this->equipes->contains($equipe)) {
            $this->equipes[] = $equipe;
            $equipe->addInscription($this);
        }

        return $this;
    }

    public function removeEquipe(Equipe $equipe): self
    {
        if ($this->equipes->removeElement($equipe)) {
            $equipe->removeInscription($this);
        }

        return $this;
    }

    /**
     * @return Collection|EquipeTennis[]
     */
    public function getEquipeTennis(): Collection
    {
        return $this->equipeTennis;
    }

    public function addEquipeTenni(EquipeTennis $equipeTenni): self
    {
        if (!$this->equipeTennis->contains($equipeTenni)) {
            $this->equipeTennis[] = $equipeTenni;
            $equipeTenni->addQualification($this);
        }

        return $this;
    }

    public function removeEquipeTenni(EquipeTennis $equipeTenni): self
    {
        if ($this->equipeTennis->removeElement($equipeTenni)) {
            $equipeTenni->removeQualification($this);
        }

        return $this;
    }

    /**
     * @return Collection|EquipeBasket[]
     */
    public function getEquipeBaskets(): Collection
    {
        return $this->equipeBaskets;
    }

    public function addEquipeBasket(EquipeBasket $equipeBasket): self
    {
        if (!$this->equipeBaskets->contains($equipeBasket)) {
            $this->equipeBaskets[] = $equipeBasket;
            $equipeBasket->addRelation($this);
        }

        return $this;
    }

    public function removeEquipeBasket(EquipeBasket $equipeBasket): self
    {
        if ($this->equipeBaskets->removeElement($equipeBasket)) {
            $equipeBasket->removeRelation($this);
        }

        return $this;
    }

    /**
     * @return Collection|Recapitulatif[]
     */
    public function getRecapitulatifs(): Collection
    {
        return $this->recapitulatifs;
    }

    public function addRecapitulatif(Recapitulatif $recapitulatif): self
    {
        if (!$this->recapitulatifs->contains($recapitulatif)) {
            $this->recapitulatifs[] = $recapitulatif;
            $recapitulatif->addFinal($this);
        }

        return $this;
    }

    public function removeRecapitulatif(Recapitulatif $recapitulatif): self
    {
        if ($this->recapitulatifs->removeElement($recapitulatif)) {
            $recapitulatif->removeFinal($this);
        }

        return $this;
    }

    /**
     * @return Collection|Tarifs[]
     */
    public function getTarifs(): Collection
    {
        return $this->tarifs;
    }

    public function addTarif(Tarifs $tarif): self
    {
        if (!$this->tarifs->contains($tarif)) {
            $this->tarifs[] = $tarif;
            $tarif->addRelation($this);
        }

        return $this;
    }

    public function removeTarif(Tarifs $tarif): self
    {
        if ($this->tarifs->removeElement($tarif)) {
            $tarif->removeRelation($this);
        }

        return $this;
    }

}
