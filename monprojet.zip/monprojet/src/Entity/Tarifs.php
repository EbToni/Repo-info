<?php

namespace App\Entity;

use App\Repository\TarifsRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=TarifsRepository::class)
 */
class Tarifs
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=200, nullable=true)
     */
    private $prix;

    /**
     * @ORM\Column(type="string", length=200, nullable=true)
     */
    private $Sport;

    /**
     * @ORM\ManyToMany(targetEntity=Tournoi::class, inversedBy="tarifs")
     */
    private $relation;

    public function __construct()
    {
        $this->relation = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getPrix(): ?string
    {
        return $this->prix;
    }

    public function setPrix(?string $prix): self
    {
        $this->prix = $prix;

        return $this;
    }

    public function getSport(): ?string
    {
        return $this->Sport;
    }

    public function setSport(?string $Sport): self
    {
        $this->Sport = $Sport;

        return $this;
    }

    /**
     * @return Collection|Tournoi[]
     */
    public function getRelation(): Collection
    {
        return $this->relation;
    }

    public function addRelation(Tournoi $relation): self
    {
        if (!$this->relation->contains($relation)) {
            $this->relation[] = $relation;
        }

        return $this;
    }

    public function removeRelation(Tournoi $relation): self
    {
        $this->relation->removeElement($relation);

        return $this;
    }
}
