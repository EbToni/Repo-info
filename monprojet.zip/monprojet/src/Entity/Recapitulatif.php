<?php

namespace App\Entity;

use App\Repository\RecapitulatifRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=RecapitulatifRepository::class)
 */
class Recapitulatif
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=200, nullable=true)
     */
    private $sport;

    /**
     * @ORM\Column(type="string", length=200, nullable=true)
     */
    private $vainqueur;

    /**
     * @ORM\Column(type="string", length=100, nullable=true)
     */
    private $resultat_pool;

    /**
     * @ORM\Column(type="string", length=250, nullable=true)
     */
    private $description;

    /**
     * @ORM\ManyToMany(targetEntity=Tournoi::class, inversedBy="recapitulatifs")
     */
    private $Final;

    public function __construct()
    {
        $this->Final = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getSport(): ?string
    {
        return $this->sport;
    }

    public function setSport(?string $sport): self
    {
        $this->sport = $sport;

        return $this;
    }

    public function getVainqueur(): ?string
    {
        return $this->vainqueur;
    }

    public function setVainqueur(?string $vainqueur): self
    {
        $this->vainqueur = $vainqueur;

        return $this;
    }

    public function getResultatPool(): ?string
    {
        return $this->resultat_pool;
    }

    public function setResultatPool(?string $resultat_pool): self
    {
        $this->resultat_pool = $resultat_pool;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): self
    {
        $this->description = $description;

        return $this;
    }

    /**
     * @return Collection|Tournoi[]
     */
    public function getFinal(): Collection
    {
        return $this->Final;
    }

    public function addFinal(Tournoi $final): self
    {
        if (!$this->Final->contains($final)) {
            $this->Final[] = $final;
        }

        return $this;
    }

    public function removeFinal(Tournoi $final): self
    {
        $this->Final->removeElement($final);

        return $this;
    }
}
