<?php

namespace App\Entity;

use App\Repository\EquipeTennisRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=EquipeTennisRepository::class)
 */
class EquipeTennis
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=200, nullable=true)
     */
    private $joueur;

    /**
     * @ORM\Column(type="string", length=200, nullable=true)
     */
    private $pool;

    /**
     * @ORM\ManyToMany(targetEntity=Tournoi::class, inversedBy="equipeTennis")
     */
    private $qualification;

    public function __construct()
    {
        $this->qualification = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getJoueur(): ?string
    {
        return $this->joueur;
    }

    public function setJoueur(?string $joueur): self
    {
        $this->joueur = $joueur;

        return $this;
    }

    public function getPool(): ?string
    {
        return $this->pool;
    }

    public function setPool(?string $pool): self
    {
        $this->pool = $pool;

        return $this;
    }

    /**
     * @return Collection|Tournoi[]
     */
    public function getQualification(): Collection
    {
        return $this->qualification;
    }

    public function addQualification(Tournoi $qualification): self
    {
        if (!$this->qualification->contains($qualification)) {
            $this->qualification[] = $qualification;
        }

        return $this;
    }

    public function removeQualification(Tournoi $qualification): self
    {
        $this->qualification->removeElement($qualification);

        return $this;
    }
}
