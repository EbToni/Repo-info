<?php

namespace App\Form;


use App\Entity\Evenement;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

use Symfony\Component\Form\FormTypeInterface;

class EvenementType extends AbstractType implements FormTypeInterface
{
    /* --- Description EvenementType ---

                                     
    1) buildForm <-> add 3 champs pour (evenement)
                             nom, dateDeb, dateFin
        <!> ici on ne mentionne pas les 
                - TextType...
            noms(champs) = noms(Evenement:class)

        params : $builder, $options

    2) configureOptions <-> précise que le form est ( type CLASS Evenement)

        params : $resolver
    
    */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('nom')
            ->add('dateDeb')
            ->add('dateFin')
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Evenement::class,
        ]);
    }
}
