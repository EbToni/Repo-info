<?php
namespace App\Form;

// crée des bug avec TextType Core
//use Doctrine\DBAL\Types\TextType;

use Symfony\Component\Form\AbstractType;

// pas besoin de le mettre puisqu'on a implémenter FormTypeInterface
//use App\Form\EvenementType;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;

use Symfony\Component\Form\FormTypeInterface;

class TournoiType extends AbstractType implements FormTypeInterface{
/*      --- Description TournoiType ---

1) buildForm <-> add 3 champs pour (tournoi)
            (EvenementType) ev
            (TextType)      nom, description
            (Bouton: envoyer)  sauver 

        params : $builder, $options

2) configureOptions(tournoi::class) se trouve dans TournoiController

*/
    public function buildForm(FormBuilderInterface $builder, array $options) : void
    {
        $builder
        ->add('ev', EvenementType::class)
        -> add('nom', TextType::class)
        ->add('description', TextType::class)
        ->add('sauver', SubmitType::class,
        ['label'=>'Créer le tournoi !']);

    }
}

