<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211217175230 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE equipe_tennis (id INT AUTO_INCREMENT NOT NULL, joueur VARCHAR(200) DEFAULT NULL, pool VARCHAR(200) DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE equipe_tennis_tournoi (equipe_tennis_id INT NOT NULL, tournoi_id INT NOT NULL, INDEX IDX_6F5D6FDF12E312AD (equipe_tennis_id), INDEX IDX_6F5D6FDFF607770A (tournoi_id), PRIMARY KEY(equipe_tennis_id, tournoi_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE equipe_tennis_tournoi ADD CONSTRAINT FK_6F5D6FDF12E312AD FOREIGN KEY (equipe_tennis_id) REFERENCES equipe_tennis (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE equipe_tennis_tournoi ADD CONSTRAINT FK_6F5D6FDFF607770A FOREIGN KEY (tournoi_id) REFERENCES tournoi (id) ON DELETE CASCADE');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE equipe_tennis_tournoi DROP FOREIGN KEY FK_6F5D6FDF12E312AD');
        $this->addSql('DROP TABLE equipe_tennis');
        $this->addSql('DROP TABLE equipe_tennis_tournoi');
    }
}
