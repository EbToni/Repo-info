<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211217184330 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE equipe_basket (id INT AUTO_INCREMENT NOT NULL, nom_equipe VARCHAR(200) DEFAULT NULL, pool VARCHAR(200) DEFAULT NULL, tour VARCHAR(200) DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE equipe_basket_tournoi (equipe_basket_id INT NOT NULL, tournoi_id INT NOT NULL, INDEX IDX_AC29BF8447909EA9 (equipe_basket_id), INDEX IDX_AC29BF84F607770A (tournoi_id), PRIMARY KEY(equipe_basket_id, tournoi_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE equipe_basket_tournoi ADD CONSTRAINT FK_AC29BF8447909EA9 FOREIGN KEY (equipe_basket_id) REFERENCES equipe_basket (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE equipe_basket_tournoi ADD CONSTRAINT FK_AC29BF84F607770A FOREIGN KEY (tournoi_id) REFERENCES tournoi (id) ON DELETE CASCADE');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE equipe_basket_tournoi DROP FOREIGN KEY FK_AC29BF8447909EA9');
        $this->addSql('DROP TABLE equipe_basket');
        $this->addSql('DROP TABLE equipe_basket_tournoi');
    }
}
