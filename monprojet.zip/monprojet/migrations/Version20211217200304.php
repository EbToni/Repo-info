<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211217200304 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE tarifs (id INT AUTO_INCREMENT NOT NULL, prix VARCHAR(200) DEFAULT NULL, sport VARCHAR(200) DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE tarifs_tournoi (tarifs_id INT NOT NULL, tournoi_id INT NOT NULL, INDEX IDX_EE79D78F5F3287F (tarifs_id), INDEX IDX_EE79D78F607770A (tournoi_id), PRIMARY KEY(tarifs_id, tournoi_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE tarifs_tournoi ADD CONSTRAINT FK_EE79D78F5F3287F FOREIGN KEY (tarifs_id) REFERENCES tarifs (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE tarifs_tournoi ADD CONSTRAINT FK_EE79D78F607770A FOREIGN KEY (tournoi_id) REFERENCES tournoi (id) ON DELETE CASCADE');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE tarifs_tournoi DROP FOREIGN KEY FK_EE79D78F5F3287F');
        $this->addSql('DROP TABLE tarifs');
        $this->addSql('DROP TABLE tarifs_tournoi');
    }
}
