<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211217190024 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE recapitulatif (id INT AUTO_INCREMENT NOT NULL, sport VARCHAR(200) DEFAULT NULL, vainqueur VARCHAR(200) DEFAULT NULL, resultat_pool VARCHAR(100) DEFAULT NULL, description VARCHAR(250) DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE recapitulatif_tournoi (recapitulatif_id INT NOT NULL, tournoi_id INT NOT NULL, INDEX IDX_49A98134850119EC (recapitulatif_id), INDEX IDX_49A98134F607770A (tournoi_id), PRIMARY KEY(recapitulatif_id, tournoi_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE recapitulatif_tournoi ADD CONSTRAINT FK_49A98134850119EC FOREIGN KEY (recapitulatif_id) REFERENCES recapitulatif (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE recapitulatif_tournoi ADD CONSTRAINT FK_49A98134F607770A FOREIGN KEY (tournoi_id) REFERENCES tournoi (id) ON DELETE CASCADE');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE recapitulatif_tournoi DROP FOREIGN KEY FK_49A98134850119EC');
        $this->addSql('DROP TABLE recapitulatif');
        $this->addSql('DROP TABLE recapitulatif_tournoi');
    }
}
