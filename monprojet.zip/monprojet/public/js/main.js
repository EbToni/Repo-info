function showday() {
    const d = new Date();
    document.getElementById("day").innerHTML = `Inscrivez vous dès aujourd'hui : ${d.getDate()}/${d.getMonth()+1}/${d.getFullYear()}`;

}



